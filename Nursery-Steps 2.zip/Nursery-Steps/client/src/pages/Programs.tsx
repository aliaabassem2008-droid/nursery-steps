import { Navigation } from "@/components/Navigation";
import { Footer } from "@/components/Footer";
import { SectionHeader } from "@/components/SectionHeader";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Check } from "lucide-react";

export default function Programs() {
  const programs = [
    {
      id: "infant-care",
      title: "Infant Care",
      age: "6 weeks - 18 months",
      image: "https://images.unsplash.com/photo-1519689680058-324335c77eba?w=800&q=80",
      description: "A warm, nurturing environment focused on sensory exploration, motor skills, and building trust with caregivers.",
      features: ["Sensory play", "Individualized schedules", "Tummy time", "Music & movement"]
    },
    {
      id: "toddler-program",
      title: "Toddler Program",
      age: "18 months - 3 years",
      image: "https://images.unsplash.com/photo-1596464716127-f9a82741b820?w=800&q=80",
      description: "Encouraging independence and social skills through guided play, circle time, and creative activities.",
      features: ["Language development", "Social interaction", "Creative arts", "Outdoor play"]
    },
    {
      id: "preschool",
      title: "Preschool",
      age: "3 - 5 years",
      image: "https://images.unsplash.com/photo-1503919545889-aef6d293c94c?w=800&q=80",
      description: "Preparing children for kindergarten with a focus on literacy, math concepts, and social-emotional readiness.",
      features: ["Pre-reading & math", "Science exploration", "Project-based learning", "Self-help skills"]
    },
    {
      id: "summer-camp",
      title: "Summer Camp",
      age: "3 - 10 years",
      image: "https://images.unsplash.com/photo-1472162072942-cd5147eb3902?w=800&q=80",
      description: "Fun-filled summer with weekly themes, outdoor adventures, and creative projects for school-aged children.",
      features: ["Outdoor games", "Weekly themes", "Field trips", "Creative workshops"]
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <div className="bg-primary text-white py-20">
        <div className="container mx-auto px-4 md:px-6 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Our Programs</h1>
          <p className="text-xl text-blue-100 max-w-2xl mx-auto">
            Developmentally appropriate curriculums designed to spark curiosity and build a lifelong love for learning.
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 md:px-6 py-20">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {programs.map((program, idx) => (
            <Card key={idx} className="overflow-hidden border-none shadow-lg hover:shadow-xl transition-all duration-300 flex flex-col">
              <div className="h-48 overflow-hidden">
                <img 
                  src={program.image} 
                  alt={program.title} 
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                />
              </div>
              <CardHeader className="p-6 pb-2">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-xs font-bold uppercase tracking-wider text-accent bg-accent/10 px-2 py-1 rounded-full">
                    {program.age}
                  </span>
                </div>
                <h3 className="text-2xl font-bold text-primary">{program.title}</h3>
              </CardHeader>
              <CardContent className="p-6 pt-2 flex-grow">
                <p className="text-gray-600 mb-6 line-clamp-3">{program.description}</p>
                <ul className="space-y-2">
                  {program.features.map((feature, i) => (
                    <li key={i} className="flex items-center gap-2 text-sm font-medium text-gray-700">
                      <div className="w-1.5 h-1.5 rounded-full bg-accent" />
                      {feature}
                    </li>
                  ))}
                </ul>
              </CardContent>
              <CardFooter className="p-6 pt-0 flex flex-col gap-3">
                <Link href={`/programs/${program.id}`} className="w-full">
                  <Button variant="outline" className="w-full border-primary text-primary hover:bg-primary/5 font-bold rounded-lg">
                    Learn More
                  </Button>
                </Link>
                <Link href="/contact" className="w-full">
                  <Button className="w-full bg-primary hover:bg-primary/90 text-white font-bold rounded-lg">
                    Inquire Now
                  </Button>
                </Link>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>

      <Footer />
    </div>
  );
}
