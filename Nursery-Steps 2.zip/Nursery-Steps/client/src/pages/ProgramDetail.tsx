import { Navigation } from "@/components/Navigation";
import { Footer } from "@/components/Footer";
import { useParams, Link } from "wouter";
import { motion } from "framer-motion";
import { CheckCircle2, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";

const programDetails: Record<string, any> = {
  "infant-care": {
    title: "Infant Care",
    age: "6 weeks - 18 months",
    description: "Our infant program provides a warm, nurturing environment where babies feel safe and loved. We focus on sensory exploration and building secure attachments.",
    highlights: [
      "Individualized sleeping and feeding schedules",
      "Daily reports on activities, meals, and naps",
      "Sensory-rich environment for exploration",
      "Nurturing staff with infant care specialization"
    ]
  },
  "toddler-program": {
    title: "Toddler Program",
    age: "18 months - 3 years",
    description: "Toddlers are natural explorers. Our program encourages independence and social interaction through guided play and hands-on activities.",
    highlights: [
      "Language development and vocabulary building",
      "Social skills and peer interaction",
      "Potty training support",
      "Fine and gross motor skill activities"
    ]
  },
  "preschool": {
    title: "Preschool",
    age: "3 - 5 years",
    description: "Our preschool program prepares children for kindergarten with a balance of academics and creative expression. We foster critical thinking and problem-solving.",
    highlights: [
      "Early literacy and math concepts",
      "Science and nature exploration",
      "Creative arts and music",
      "Emotional intelligence and self-regulation"
    ]
  },
  "summer-camp": {
    title: "Summer Camp",
    age: "3 - 10 years",
    description: "Summer at Steps is all about fun! Our camp features weekly themes, outdoor adventures, and creative projects that keep children engaged all summer long.",
    highlights: [
      "Weekly themed adventures",
      "Outdoor games and water play",
      "Special guests and field trips",
      "Art, science, and sports workshops"
    ]
  }
};

export default function ProgramDetail() {
  const { id } = useParams();
  const program = programDetails[id || ""];

  if (!program) return null;

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <div className="pt-20 pb-32">
        <div className="container mx-auto px-4 md:px-6">
          <Link href="/programs">
            <Button variant="ghost" className="mb-8 hover:bg-primary/5 flex items-center gap-2">
              <ArrowLeft className="w-4 h-4" /> Back to Programs
            </Button>
          </Link>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
            >
              <span className="text-accent font-bold uppercase tracking-wider text-sm">{program.age}</span>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-primary mt-2 mb-6">
                {program.title}
              </h1>
              <p className="text-xl text-gray-600 leading-relaxed mb-8">
                {program.description}
              </p>
              
              <div className="space-y-4">
                {program.highlights.map((highlight: string, idx: number) => (
                  <div key={idx} className="flex items-center gap-3">
                    <CheckCircle2 className="w-6 h-6 text-accent shrink-0" />
                    <span className="text-lg text-gray-700 font-medium">{highlight}</span>
                  </div>
                ))}
              </div>

              <Link href="/contact">
                <Button size="lg" className="mt-12 rounded-full bg-accent hover:bg-accent/90 px-10 h-14 text-lg font-bold">
                  Inquire Now
                </Button>
              </Link>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.2 }}
              className="bg-primary/5 rounded-[3rem] p-8 aspect-square flex items-center justify-center"
            >
               <div className="text-primary/20 text-9xl font-bold uppercase rotate-12 select-none">
                 {program.title.charAt(0)}
               </div>
            </motion.div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}
