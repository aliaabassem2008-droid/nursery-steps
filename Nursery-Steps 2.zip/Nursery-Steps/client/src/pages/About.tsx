import { Navigation } from "@/components/Navigation";
import { Footer } from "@/components/Footer";
import { SectionHeader } from "@/components/SectionHeader";
import { motion } from "framer-motion";

export default function About() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      {/* Page Header */}
      <div className="bg-primary text-white py-20">
        <div className="container mx-auto px-4 md:px-6 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">About Us</h1>
          <p className="text-xl text-blue-100 max-w-2xl mx-auto">
            Our mission is to provide a safe, nurturing, and stimulating environment where children can grow and thrive.
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 md:px-6 py-20">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-24">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
          >
            {/* teacher helping child with puzzle */}
            <img 
              src="https://images.unsplash.com/photo-1587654780291-39c9404d746b?w=800&q=80" 
              alt="Teacher helping child" 
              className="rounded-3xl shadow-2xl border-4 border-white"
            />
          </motion.div>
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
          >
            <SectionHeader title="Our Philosophy" subtitle="Who We Are" centered={false} />
            <p className="text-gray-600 text-lg leading-relaxed mb-6">
              At Steps Nursery, we believe that early childhood is a critical time for development. Our approach focuses on the whole child—fostering cognitive, social, emotional, and physical growth.
            </p>
            <p className="text-gray-600 text-lg leading-relaxed">
              We create a play-based learning environment where children are encouraged to explore, ask questions, and discover the world around them at their own pace. Our passionate educators act as guides, supporting each child's unique journey.
            </p>
          </motion.div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            { title: "Our Mission", text: "To empower young minds through creative play and structured learning." },
            { title: "Our Vision", text: "A community where every child feels valued, safe, and excited to learn." },
            { title: "Our Values", text: "Respect, Creativity, Safety, Inclusivity, and Partnership with Families." }
          ].map((item, idx) => (
            <div key={idx} className="bg-secondary/20 p-8 rounded-2xl border border-gray-100">
              <h3 className="text-2xl font-bold text-primary mb-4">{item.title}</h3>
              <p className="text-gray-600">{item.text}</p>
            </div>
          ))}
        </div>
      </div>

      <Footer />
    </div>
  );
}
