import { Navigation } from "@/components/Navigation";
import { Footer } from "@/components/Footer";
import { motion } from "framer-motion";
import { Cake, Music, Palette, Gift, PartyPopper } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function BirthdayParties() {
  const packages = [
    {
      title: "Classic Party",
      description: "A fun-filled 2-hour celebration with organized games and activities.",
      features: ["Decorated venue", "Dedicated party host", "Music and sound system", "Basic snack package"]
    },
    {
      title: "Themed Adventure",
      description: "Pick a theme and let us handle the rest - from superheroes to princesses!",
      features: ["Themed decorations", "Custom activities", "Character appearances (optional)", "Themed party favors"]
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <div className="pt-20 pb-32">
        <div className="container mx-auto px-4 md:px-6">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center max-w-3xl mx-auto mb-20"
          >
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-primary mb-6">
              Birthday Parties
            </h1>
            <p className="text-xl text-gray-600">
              Make your child's special day unforgettable with our custom birthday party packages!
            </p>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-20">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="bg-accent/5 rounded-[3rem] p-12 flex flex-col justify-center"
            >
              <h2 className="text-3xl font-bold text-primary mb-6">Celebrate with Steps</h2>
              <p className="text-lg text-gray-700 mb-8 leading-relaxed">
                We offer a safe, spacious, and fun environment for children to celebrate their birthdays. Our team handles all the details so you can enjoy the moment with your little one.
              </p>
              <div className="grid grid-cols-2 gap-6">
                <div className="flex items-center gap-3">
                  <Music className="w-6 h-6 text-accent" />
                  <span className="font-bold text-primary">Music & Fun</span>
                </div>
                <div className="flex items-center gap-3">
                  <Palette className="w-6 h-6 text-accent" />
                  <span className="font-bold text-primary">Arts & Crafts</span>
                </div>
                <div className="flex items-center gap-3">
                  <Cake className="w-6 h-6 text-accent" />
                  <span className="font-bold text-primary">Cake Cutting</span>
                </div>
                <div className="flex items-center gap-3">
                  <Gift className="w-6 h-6 text-accent" />
                  <span className="font-bold text-primary">Gift Station</span>
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="relative aspect-square bg-primary/5 rounded-[3rem] overflow-hidden flex items-center justify-center"
            >
              <PartyPopper className="w-48 h-48 text-primary/10 rotate-12" />
            </motion.div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {packages.map((pkg, idx) => (
              <div key={idx} className="bg-white p-8 rounded-[2rem] shadow-lg border-2 border-primary/5">
                <h3 className="text-2xl font-bold text-primary mb-4">{pkg.title}</h3>
                <p className="text-gray-600 mb-6">{pkg.description}</p>
                <ul className="space-y-3 mb-8">
                  {pkg.features.map((feature, i) => (
                    <li key={i} className="flex items-center gap-3 text-gray-700">
                      <div className="w-2 h-2 rounded-full bg-accent" />
                      <span className="font-medium">{feature}</span>
                    </li>
                  ))}
                </ul>
                <Link href="/contact">
                  <Button className="w-full rounded-full bg-primary hover:bg-primary/90 font-bold">
                    Inquire About Dates
                  </Button>
                </Link>
              </div>
            ))}
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}
