import { Link } from "wouter";
import { motion } from "framer-motion";
import { ArrowRight, ShieldCheck, Heart, BookOpen, Star } from "lucide-react";
import { Navigation } from "@/components/Navigation";
import { Footer } from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { SectionHeader } from "@/components/SectionHeader";

export default function Home() {
  const features = [
    {
      icon: <ShieldCheck className="w-8 h-8 text-accent" />,
      title: "Safe Environment",
      description:
        "State-of-the-art security systems and child-proof facilities in our Maadi branch ensure your little one is always safe.",
    },
    {
      icon: <BookOpen className="w-8 h-8 text-accent" />,
      title: "Play-Based Learning",
      description:
        "Our curriculum balances structured learning with creative play to spark curiosity and growth.",
    },
    {
      icon: <Heart className="w-8 h-8 text-accent" />,
      title: "Caring Staff",
      description:
        "Our certified educators are passionate about nurturing every child's unique potential.",
    },
  ];

  const testimonials = [
    {
      name: "Sarah Johnson",
      role: "Parent of Toddler",
      content:
        "Steps has been a blessing for our family. The staff truly cares about each child's development.",
    },
    {
      name: "Michael Chen",
      role: "Parent of Preschooler",
      content:
        "My son comes home every day excited to share what he learned. The programs are fantastic!",
    },
    {
      name: "Emily Rodriguez",
      role: "Parent of Infant",
      content:
        "I was nervous about leaving my baby, but the warmth and professionalism here put me at ease immediately.",
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-secondary/30 pt-16 pb-32">
        <div className="container mx-auto px-4 md:px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
              className="z-10"
            >
              <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold text-primary leading-tight mb-6">
                Small Steps, <br />
                <span className="text-accent">Big Dreams</span>
              </h1>
              <p className="text-xl text-gray-600 mb-8 max-w-lg leading-relaxed">
                Nurturing young minds in a safe, loving, and creative
                environment where every day is a new adventure.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link href="/contact">
                  <Button
                    size="lg"
                    className="rounded-full bg-accent hover:bg-accent/90 text-white text-lg font-bold px-8 h-14 shadow-lg shadow-accent/25 hover:-translate-y-1 transition-all"
                  >
                    Schedule a Tour
                  </Button>
                </Link>
                <Link href="/programs">
                  <Button
                    size="lg"
                    variant="outline"
                    className="rounded-full border-2 border-primary text-primary hover:bg-primary/5 text-lg font-bold px-8 h-14"
                  >
                    Explore Programs
                  </Button>
                </Link>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="relative"
            >
              <div className="absolute inset-0 bg-accent/5 rounded-full filter blur-3xl transform scale-110"></div>
              <div className="relative bg-white p-8 rounded-[3rem] shadow-2xl rotate-2 hover:rotate-0 transition-transform duration-500 border-8 border-primary/10 flex items-center justify-center">
                <img
                  src="/assets/logo.png"
                  alt="Steps Play School Logo"
                  className="w-full max-w-[400px] h-auto object-contain"
                />
              </div>
            </motion.div>
          </div>
        </div>

        {/* Decorative Wave */}
        <div className="absolute bottom-0 left-0 w-full overflow-hidden leading-none">
          <svg
            className="relative block w-full h-[100px]"
            data-name="Layer 1"
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 1200 120"
            preserveAspectRatio="none"
          >
            <path
              d="M321.39,56.44c58-10.79,114.16-30.13,172-41.86,82.39-16.72,168.19-17.73,250.45-.39C823.78,31,906.67,72,985.66,92.83c70.05,18.48,146.53,26.09,214.34,3V0H0V27.35A600.21,600.21,0,0,0,321.39,56.44Z"
              className="fill-white"
            ></path>
          </svg>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-24 bg-white">
        <div className="container mx-auto px-4 md:px-6">
          <SectionHeader
            title="Why Parents Choose Steps"
            subtitle="The Steps Difference"
          />

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {features.map((feature, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
              >
                <Card className="border-none shadow-lg hover:shadow-xl transition-shadow bg-secondary/20 h-full">
                  <CardContent className="p-8 text-center flex flex-col items-center h-full">
                    <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center shadow-sm mb-6">
                      {feature.icon}
                    </div>
                    <h3 className="text-xl font-bold text-primary mb-3">
                      {feature.title}
                    </h3>
                    <p className="text-gray-600 leading-relaxed">
                      {feature.description}
                    </p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Programs Preview */}
      <section className="py-24 bg-primary text-white">
        <div className="container mx-auto px-4 md:px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <span className="inline-block px-4 py-1 rounded-full bg-accent/20 text-accent font-bold text-sm tracking-wide uppercase mb-3">
                Our Programs
              </span>
              <h2 className="text-4xl md:text-5xl font-bold mb-6">
                Age-Appropriate Learning for Every Stage
              </h2>
              <p className="text-gray-300 text-lg mb-8 leading-relaxed">
                We believe that every child is unique. Our programs are designed
                to meet the developmental needs of each age group, fostering
                social, emotional, and cognitive growth.
              </p>
              <ul className="space-y-4 mb-8">
                {[
                  "Infants (6 weeks - 18 months)",
                  "Toddlers (18 months - 3 years)",
                  "Preschool (3 - 5 years)",
                ].map((item, i) => (
                  <li key={i} className="flex items-center gap-3">
                    <div className="w-6 h-6 rounded-full bg-accent flex items-center justify-center shrink-0">
                      <ArrowRight className="w-3 h-3 text-white" />
                    </div>
                    <span className="font-medium text-lg">{item}</span>
                  </li>
                ))}
              </ul>
              <Link href="/programs">
                <Button className="bg-white text-primary hover:bg-gray-100 font-bold rounded-full px-8 h-12">
                  View All Programs
                </Button>
              </Link>
            </div>
            <div className="grid grid-cols-2 gap-4">
              {/* kids painting art class */}
              <img
                src="https://images.unsplash.com/photo-1503454537195-1dcabb73ffb9?w=600&q=80"
                alt="Child painting"
                className="rounded-2xl shadow-lg mt-12"
              />
              {/* teacher reading book to kids */}
              <img
                src="https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=600&q=80"
                alt="Teacher reading"
                className="rounded-2xl shadow-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-24 bg-secondary/30">
        <div className="container mx-auto px-4 md:px-6">
          <SectionHeader title="What Families Say" subtitle="Testimonials" />

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((t, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
              >
                <Card className="border-none shadow-md h-full">
                  <CardContent className="p-8">
                    <div className="flex gap-1 mb-4">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <Star
                          key={star}
                          className="w-5 h-5 text-yellow-400 fill-current"
                        />
                      ))}
                    </div>
                    <p className="text-gray-600 mb-6 italic">"{t.content}"</p>
                    <div>
                      <h4 className="font-bold text-primary">{t.name}</h4>
                      <span className="text-sm text-gray-400">{t.role}</span>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 md:px-6 text-center">
          <div className="max-w-3xl mx-auto bg-primary rounded-3xl p-12 relative overflow-hidden">
            {/* Decorative circles */}
            <div className="absolute top-0 right-0 w-64 h-64 bg-accent/10 rounded-full -translate-y-1/2 translate-x-1/2"></div>
            <div className="absolute bottom-0 left-0 w-48 h-48 bg-white/5 rounded-full translate-y-1/2 -translate-x-1/2"></div>

            <div className="relative z-10">
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
                Ready to Join Our Family?
              </h2>
              <p className="text-blue-100 mb-8 text-lg">
                Schedule a tour today to see our facilities and meet our
                wonderful staff.
              </p>
              <Link href="/contact">
                <Button
                  size="lg"
                  className="bg-accent hover:bg-accent/90 text-white font-bold rounded-full px-8 h-12 shadow-lg"
                >
                  Enroll Your Child
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
