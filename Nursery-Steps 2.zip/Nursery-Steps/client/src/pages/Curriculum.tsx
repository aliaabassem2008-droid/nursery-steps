import { Navigation } from "@/components/Navigation";
import { Footer } from "@/components/Footer";
import { motion } from "framer-motion";
import { BookOpen, Languages, Users, Star } from "lucide-react";

export default function Curriculum() {
  const sections = [
    {
      title: "Class Divisions",
      icon: Users,
      content: "Our classes are divided by age groups to ensure developmentally appropriate learning and socialization.",
      items: [
        "Little Sprouts (Infants): 6 weeks - 18 months",
        "Tiny Tots (Toddlers): 18 months - 3 years",
        "Young Explorers (Preschool): 3 - 5 years",
        "Summer Adventurers: 3 - 10 years"
      ]
    },
    {
      title: "Core Curriculum",
      icon: BookOpen,
      content: "We follow a holistic curriculum that balances academic readiness with social-emotional growth.",
      items: [
        "Early Literacy & Phonics",
        "Mathematical Concepts & Problem Solving",
        "Science & Nature Discovery",
        "Creative Arts & Music Expression"
      ]
    },
    {
      title: "Languages",
      icon: Languages,
      content: "We provide a bilingual environment to foster early language acquisition and cultural awareness.",
      items: [
        "English: Main language of instruction",
        "Arabic: Native language and cultural studies",
        "French: Introductory conversational sessions",
        "Daily storytime in multiple languages"
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <div className="pt-20 pb-32">
        <div className="container mx-auto px-4 md:px-6">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center max-w-3xl mx-auto mb-20"
          >
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-primary mb-6">
              Curriculum & Class Divisions
            </h1>
            <p className="text-xl text-gray-600">
              Discover how we nurture young minds through our comprehensive educational framework and age-appropriate class structures.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {sections.map((section, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.1 }}
                className="bg-white p-8 rounded-[2rem] shadow-lg border-2 border-primary/5 hover:border-accent/20 transition-all"
              >
                <div className="w-16 h-16 bg-accent/10 rounded-2xl flex items-center justify-center mb-6">
                  <section.icon className="w-8 h-8 text-accent" />
                </div>
                <h3 className="text-2xl font-bold text-primary mb-4">{section.title}</h3>
                <p className="text-gray-600 mb-6">{section.content}</p>
                <ul className="space-y-3">
                  {section.items.map((item, i) => (
                    <li key={i} className="flex items-center gap-3 text-gray-700">
                      <Star className="w-4 h-4 text-accent fill-accent" />
                      <span className="font-medium">{item}</span>
                    </li>
                  ))}
                </ul>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}
